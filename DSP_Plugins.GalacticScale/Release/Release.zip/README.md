﻿# DSP GalacticScale Mod

# No Longer Supported. Please get the new version

https://dsp.thunderstore.io/package/Galactic_Scale/GalacticScale/


After a looooong time, Inno have been at work hard to bug fix a shit ton of stuff ! 
Hang on discord for the full changelog

This release should help a lot and we hope that we can get our first playthrought on this version without breaking bugs.

[BETA] 1.3.3 :  Go to the discord for the changelogs , help and instructions about the mod :)

/!\ READ THIS 

# Discord for Galactic Scale's team work
https://discord.gg/NbpBn6gM6d --> It will not replace the modding discord community. But at least it will be easier to talk about the mod and ask me directly questions :)

#Patch notes & releases :
You can find all the releases and the patch notes here : https://github.com/Touhma/DSP_Plugins/releases

#Bug report :
Go on the discord or post a ticket here :
https://github.com/Touhma/DSP_Plugins/issues

## Disclaimer
The version 1.0.1 is the one you want if you are looking only for the slider for more stars
All version after are Beta release to test the new algorithm for the generation of entire systems. --> Heavily in development

This mod is pretty much incompatible with anything touching on any part of the generation : we will not support any compatibility before the release.

A beta release mean : bugs , save broken, etc ... it's EXPERIMENTAL Please report any issues on the github.

We need some feedback & some bug report to fix it. Plus we are open to peoples who think can help us fixing it.

Have fun with it and good testing !

## How to Install :

First Install Bepinex in your game
folder : https://bepinex.github.io/bepinex_docs/master/articles/user_guide/installation/index.html?tabs=tabid-win

Then Download the latest DLL of the mod : https://github.com/Touhma/DSP_Plugins/releases

And add it in depinex plugins folder in your game : %gamefolder%\Dyson Sphere Program\BepInEx\plugins

Launch the game and you should be all set !

## How to use galactic-scale ?

All the information are here : https://github.com/Touhma/DSP_Plugins/wiki

It's still incomplete but you will have all the basics information there & in the configs files.

## For modders :

We spent a shit ton of time working on that mod so please ... don't be a dick.
If you have some features ideas that would need my code to work, talk to the main dev first ( Touhma#1599 ) on Discord about it then we shall decide how we can proceed.
If you can : make your own work using this mod as a dependency if you don't wanna improve this mod.
If you wanna fix something in it or improve on it --> please go ahead and do a pull request, we'll happily credit you for your work.

Do NOT make a mod just to change the default configuration or a few parameters, DO share your configs files with us :) if it's giving good result it can make it to the official release of the mod.

We would love that mod to be a reference in the community concerning everything around the generation of the moons, planets, stars, etc ... We have a shit tons of ideas for it and we'll probably not be able to take care of everything by ourself as fast as we wish for. So consider helping me improving it instead of copy pasting the code & releasing it under a new name.

This mod is and will always be free of charge for everyone.

We'll see in the future if people wanna give us a pint of beer if they wanna support me but again : it will stay open & free of charge for everyone.

If you wanna reuse some piece of code : make your own work free of charge & open source too .
